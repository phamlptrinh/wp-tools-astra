<?php

namespace GpcChildTheme\Site;

use Carbon_Fields\Container;
use Carbon_Fields\Field;
use GpcChildTheme\Includes\Traits\Singleton;

class SiteSettings
{
    use Singleton;

    public function __construct()
    {
        add_action('carbon_fields_register_fields', [$this, 'add_settings']);
    }

    public function add_settings()
    {
        $social_networks = [
            'phone' => 'Phone',
            'email' => 'Email',
            'zalo' => 'Zalo',
            'facebook' => 'Facebook',
            'messenger' => 'Messenger',
            'youtube' => 'Youtube',
            'instagram' => 'Instagram',
            'tiktok' => 'Tiktok',
            'other' => 'Khác',
        ];
        $social_networks_json = json_encode( $social_networks );

        Container::make('theme_options', 'GPC Settings')
            ->set_page_parent('options-general.php')
            /* Tab hệ thống */
            ->add_tab(__('Hệ thống'), array(
                Field::make('checkbox', 'gpc_hide_update_notices', __('Ẩn thông báo cập nhật')),
                Field::make('checkbox', 'gpc_disable_wp_file_editor', __('Disable WP file editor')),
            ))
            /* Tab nút liên hệ */
            ->add_tab(__('Nút liên hệ'), array(
                Field::make('html', 'floating_buttons_information_text')
                    ->set_html('<h2>Lưu ý:</h2>
                <ul>
                    <li>Các nút liên hệ ở đây chỉ là nút bấm dẫn sang zalo messenger hoặc FB messenger...</li>
                    <li><span style="color:red;">Nếu muốn sử dụng chatbox của zalo, facebook... thì đặt code ở bên <b>Header & Footer Scripts</b></span></li>
                    <li>
                        Màu sắc tham khảo:
                        <ul>
                            <li>Facebook Messenger: #0084ff</li>
                            <li>Zalo: #1F7FC2</li>
                            <li>Viber: #665cac</li>
                            <li>Whatsapp: #00bfa5</li>
                            <li>Instagram: #9b6954</li>
                            <li>Youtube: #FF0000</li>
                        </ul>
                    </li>
                </ul> '),
                Field::make('html', 'text_space_left')
                    ->set_html('<h3>Các nút bên trái: </h3>'),
                Field::make('checkbox', 'gpc_floating_buttons_left_show', 'Hiển thị nút liên hệ bên trái'),
                Field::make('set', 'gpc_floating_buttons_left_has_effect', __('Bật hiệu ứng rung cho nút liên hệ bên trái'))
                    ->set_options(array(
                        'desktop' => 'Desktop',
                        'tablet' => 'Tablet',
                        'mobile' => 'Mobile',
                    )),
                Field::make('complex', 'gpc_floating_buttons_left', __('Các nút liên hệ bên trái'))
                    ->add_fields(array(
                            Field::make('select', 'type', 'Loại')->set_options($social_networks),
                            Field::make('text', 'title', 'Title'),
                            Field::make('text', 'link', 'Link'),
                            Field::make('text', 'phone', 'Số điện thoại')->set_conditional_logic([
                                ['field' => 'type', 'value' => 'zalo'],
                            ]),
                            Field::make('text', 'qrcode', 'Mã QR Zalo')->set_conditional_logic([
                                ['field' => 'type', 'value' => 'zalo'],
                            ]),
                            Field::make('image', 'icon_image', __('Icon image')),
                            Field::make('color', 'color', 'Màu nền')->set_alpha_enabled(true),
                            Field::make('text', 'css_class', 'Extra CSS Classes'),
                            Field::make('checkbox', 'is_in_another_side', 'Hiển thị khác bên mặc định'),
                        ))
                        ->set_header_template('<%-' . $social_networks_json . '[type] %> - <%- title %>')
                         ->set_collapsed(true),

                Field::make('html', 'text_space_right')
                    ->set_html('<h3>Các nút bên phải: </h3>'),
                Field::make('checkbox', 'gpc_floating_buttons_right_show', 'Hiển thị nút liên hệ bên phải'),
                Field::make('set', 'gpc_floating_buttons_right_has_effect', __('Bật hiệu ứng rung cho nút liên hệ bên phải'))
                    ->set_options(array(
                        'desktop' => 'Desktop',
                        'tablet' => 'Tablet',
                        'mobile' => 'Mobile',
                    )),
                Field::make('complex', 'gpc_floating_buttons_right', __('Các nút liên hệ bên phải'))
                    ->add_fields(array(
                            Field::make('select', 'type', 'Loại')->set_options($social_networks),
                            Field::make('text', 'title', 'Title'),
                            Field::make('text', 'link', 'Link'),
                            Field::make('text', 'phone', 'Số điện thoại')->set_conditional_logic([
                                ['field' => 'type', 'value' => 'zalo'],
                            ]),
                            Field::make('text', 'qrcode', 'Mã QR Zalo')->set_conditional_logic([
                                ['field' => 'type', 'value' => 'zalo'],
                            ]),
                            Field::make('image', 'icon_image', __('Icon image')),
                            Field::make('color', 'color', 'Màu nền')->set_alpha_enabled(true),
                            Field::make('text', 'css_class', 'Extra CSS Classes'),
                            Field::make('checkbox', 'is_in_another_side', 'Hiển thị khác bên mặc định'),
                        ))
                        ->set_header_template('<%-' . $social_networks_json . '[type] %> - <%- title %>')
                         ->set_collapsed(true),

                Field::make('html', 'text_space_general')
                    ->set_html('<h3>Tùy chọn chung: </h3>'),
                Field::make('checkbox', 'gpc_floating_buttons_fix_zalo', __('Chạy code sửa lỗi zalo')),
                Field::make('checkbox', 'gpc_floating_buttons_mobile_fixed', __('Cố định nút trên mobile')),
                Field::make('checkbox', 'gpc_floating_buttons_reverse_order_on_mobile', __('Đảo thứ tự trái phải trên mobile')),
            ))
            /* Tab header - footer scripts */
            ->add_tab(__('Header - Footer Script'), array(
                Field::make('header_scripts', 'gpc_header_scripts', __('Header Scripts'))
                    ->set_hook('wp_head', 100),

                Field::make('header_scripts', 'gpc_body_scripts', __('Body Scripts'))
                    ->set_hook('wp_body_open', 10),

                Field::make('footer_scripts', 'gpc_footer_scripts', __('Footer Scripts'))
                    ->set_hook('wp_footer', 100),
            ));
    }
}
