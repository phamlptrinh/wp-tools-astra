<?php
namespace GpcChildTheme\Site;

use GpcChildTheme\Includes\Blocks\GpcDummy;
use GpcChildTheme\Includes\Compatibility\AstraTheme;
use GpcChildTheme\Includes\Compatibility\KadenceBlocks;
use GpcChildTheme\Includes\Compatibility\KadenceTheme;
use GpcChildTheme\Includes\DisableUpdates;
use GpcChildTheme\Includes\FloatContactButtons;
use GpcChildTheme\Includes\HideKadenceActiveNotification;
use GpcChildTheme\Includes\HideWPFileEditor;
use GpcChildTheme\Includes\Shortcodes\CategoriesShortcode;
use GpcChildTheme\Includes\Shortcodes\DateShortcode;
use GpcChildTheme\Includes\TinyEditor;
use GpcChildTheme\Includes\Traits\Singleton;
use GpcChildTheme\Includes\Widgets\LegacyWidgets;

class SiteInit
{
    use Singleton;

	public function __construct()
	{
		add_action( 'after_setup_theme', array( $this, 'load_carbon_fields' ) );

		$this->theme_setup();
		$this->register_post_types();
		$this->register_blocks();
		$this->load_admin();
		$this->load_public();
	}

	public function load_carbon_fields()
	{
		\Carbon_Fields\Carbon_Fields::boot();
	}

	public function theme_setup()
	{
		new AstraTheme();
		new KadenceTheme();
	}

	public function register_post_types()
	{
	}

	public function register_blocks()
	{
		new KadenceBlocks();
		new BlockStyles();

		new GpcDummy();
	}

	public function load_admin()
	{
		// Load admin JS & CSS.
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 10, 1 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_styles' ), 10, 1 );

		// Load css, js in block editor
		add_action( 'enqueue_block_editor_assets', [ $this, 'enqueue_block_editor_assets' ], 11 );

		// create setting page
		SiteSettings::instance();

		// Chỉnh button trên TinyMCE
		new TinyEditor();
		// Mở các widget cũ trong trang quản lý widget khi ở chế độ block editor
		new LegacyWidgets();
		// Tắt thông báo cập nhật
		new DisableUpdates();
	}

	public function load_public()
	{
		add_action( 'wp_enqueue_scripts', [ $this, 'add_fontawesome' ]);
		add_action( 'wp_enqueue_scripts', [ $this, 'child_enqueue_styles' ], 99 );

		// Thêm css, js cho từng page, dùng khi làm landing page hoặc khi cần gắn css, js riêng cho 1 page cụ thể
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_page_assets' ], 98 );

		new DateShortcode();
		new CategoriesShortcode();
		new FloatContactButtons();
		new HideWPFileEditor();
	}

	public function add_fontawesome()
	{
		wp_enqueue_style( 'gpc-fa', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css', array(), '5.9.0' );
	}

	public function enqueue_page_assets()
	{

		$homeId = get_option('page_on_front');

		$pages = [
			'home' => $homeId,
		];

		if ( is_page( $pages['home'] ) ) {

		}
	}

	public function child_enqueue_styles()
	{
		/*---------- slider ---------- */
		wp_enqueue_style( 'slick', get_stylesheet_directory_uri() . '/assets/vendor/slick/slick.css', array(), '1.8.1' );
		wp_enqueue_style( 'slick-theme', get_stylesheet_directory_uri() . '/assets/vendor/slick/slick-theme.css', array(), '1.8.1' );
		wp_enqueue_script( 'slick', get_stylesheet_directory_uri() . '/assets/vendor/slick/slick.min.js', array('jquery'), '1.8.1', true );

		/*---------- lightbox ---------- */
		wp_register_style( 'kadence-glightbox', KADENCE_BLOCKS_URL . 'includes/assets/css/kb-glightbox.min.css', array(), KADENCE_BLOCKS_VERSION );
		wp_register_script( 'kadence-glightbox', KADENCE_BLOCKS_URL . 'includes/assets/js/glightbox.min.js', array(), KADENCE_BLOCKS_VERSION, true );

		/*---------- datepicker ---------- */
		wp_enqueue_style( 'gdatepicker-css', get_stylesheet_directory_uri() . '/assets/js/gpcdtp/gdatetimepicker.css', array(), '1.0.0' );
		wp_enqueue_script( 'gdatepicker-js', get_stylesheet_directory_uri() . '/assets/js/gpcdtp/gdatetimepicker.js', array(), '1.0.0', true );

		wp_enqueue_style( 'gpc-child-theme-base-css', get_stylesheet_directory_uri() . '/assets/css/frontend.css', array(), filemtime(get_stylesheet_directory(). '/assets/css/frontend.css') );
		wp_enqueue_style( 'gpc-child-theme-css', get_stylesheet_directory_uri() . '/style.css', array(), filemtime(get_stylesheet_directory(). '/style.css') );
		wp_enqueue_script('gpc-child-theme-js', get_stylesheet_directory_uri() . '/assets/js/frontend.js', array('jquery'), filemtime(get_stylesheet_directory(). '/assets/js/frontend.js'), true );
	}

	public function admin_enqueue_styles( $hook = '' )
	{
		wp_register_style( 'gpc-child-theme-admin', esc_url( GPC_CHILD_THEME_DIR_URL ) . '/assets/css/admin.css', array(), GPC_CHILD_THEME_VERSION );
		wp_enqueue_style( 'gpc-child-theme-admin' );
	}

	public function admin_enqueue_scripts( $hook = '' )
	{
		wp_register_script( 'gpc-child-theme-admin', esc_url( GPC_CHILD_THEME_DIR_URL ) . '/assets/js/admin.js', array( 'jquery' ), GPC_CHILD_THEME_VERSION, true );
		wp_enqueue_script( 'gpc-child-theme-admin' );
	}

	public function enqueue_block_editor_assets()
	{
		wp_enqueue_style( 'gpc-editor-css', get_stylesheet_directory_uri() . '/editor-style.css', array(), filemtime(get_stylesheet_directory(). '/editor-style.css') );
	}
}