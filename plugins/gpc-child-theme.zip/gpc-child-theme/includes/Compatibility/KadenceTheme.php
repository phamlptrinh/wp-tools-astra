<?php
namespace GpcChildTheme\Includes\Compatibility;

class KadenceTheme
{
    public function __construct()
    {
        if ( get_option( 'template' ) !== 'kadence' ) {
            return;
        }

        remove_action( 'admin_notices', [ \KadenceWP\KadencePro\Uplink\Connect::get_instance(), 'inactive_notice'] );
    }
}