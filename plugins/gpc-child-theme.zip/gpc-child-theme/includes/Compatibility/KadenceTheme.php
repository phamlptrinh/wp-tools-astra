<?php
namespace GpcChildTheme\Includes\Compatibility;

class KadenceTheme
{
    public function __construct()
    {
        if ( get_option( 'template' ) !== 'kadence' ) {
            return;
        }

        if (class_exists('\KadenceWP\KadencePro\Uplink\Connect')) {
            remove_action( 'admin_notices', [ \KadenceWP\KadencePro\Uplink\Connect::get_instance(), 'inactive_notice'] );
        }
    }
}