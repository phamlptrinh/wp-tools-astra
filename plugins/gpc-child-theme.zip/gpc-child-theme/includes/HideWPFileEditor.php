<?php

namespace GpcChildTheme\Includes;

class HideWPFileEditor
{
    public function __construct()
    {
        add_action( 'init', array( $this, 'disable_wp_file_editor' ) );
    }

    public function disable_wp_file_editor()
    {
        if ( empty( carbon_get_theme_option('gpc_disable_wp_file_editor') ) ) {
            return;
        }

        define('DISALLOW_FILE_EDIT', true);
    }
}