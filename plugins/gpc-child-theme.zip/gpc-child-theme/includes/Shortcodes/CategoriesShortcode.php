<?php
namespace GpcChildTheme\Includes\Shortcodes;

use GpcChildTheme\Includes\Traits\Singleton;

class CategoriesShortcode
{
    use Singleton;

    public function __construct()
    {
        add_shortcode( 'gpc-categories', array( $this, 'render' ) );
    }

    public function render( $atts )
    {
        $list = wp_list_categories( array(
            'taxonomy'   => 'category',
            'hide_empty' => 0,
            'echo'       => '',
            'title_li'   => '',
        ) );

        $li_all_class = is_home() ? 'current-cat' : '';
        $li_all = '<li class="cat-item '. $li_all_class .'"><a href="'.esc_url(get_permalink(get_option('page_for_posts'))).'">Tất cả</a></li>';

        return '<ul class="blog-categories-list">' . $li_all . $list . "</ul>";
    }
}