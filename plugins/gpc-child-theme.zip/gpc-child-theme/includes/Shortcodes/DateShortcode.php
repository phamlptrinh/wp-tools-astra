<?php
namespace GpcChildTheme\Includes\Shortcodes;

class DateShortcode
{
    public function __construct()
    {
        add_shortcode( 'date', array( $this, 'date_shortcode' ) );
    }

    public function date_shortcode( $atts )
    {
        $atts = shortcode_atts(
            array(
                'format' => '',
            ), $atts
        );

        if ( ! empty( $atts['format'] ) ) {
            $dateFormat = sanitize_text_field( $atts['format'] );
        } else {
            $dateFormat = 'd/m/Y';
        }

        return date_i18n( $dateFormat );
    }
}