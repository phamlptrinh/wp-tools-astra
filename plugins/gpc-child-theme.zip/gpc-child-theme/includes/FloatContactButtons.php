<?php

namespace GpcChildTheme\Includes;

class FloatContactButtons
{
    public function __construct()
    {
        add_action('carbon_fields_fields_registered', [$this, 'init']);
    }

    public function init()
    {
        $contact_buttons_left = carbon_get_theme_option('gpc_floating_buttons_left');
        $contact_buttons_right = carbon_get_theme_option('gpc_floating_buttons_right');
        $buttons_show_left = carbon_get_theme_option('gpc_floating_buttons_left_show');
        $buttons_show_right = carbon_get_theme_option('gpc_floating_buttons_right_show');


        $show_left = count($contact_buttons_left) > 0 && !empty($buttons_show_left);
        $show_right = count($contact_buttons_right) > 0 &&  !empty($buttons_show_right);

        if (! $show_right && ! $show_left) {
            return;
        }

        add_action('wp_enqueue_scripts', [$this, 'wp_enqueue_scripts'], 999);
        add_action('wp_footer', [$this, 'gpc_contact_buttons'], 5);
    }

    public function wp_enqueue_scripts()
    {
        wp_enqueue_style('gpc-fcb', get_stylesheet_directory_uri() . '/assets/css/float-contact-buttons.css', array(), filemtime(get_stylesheet_directory() . '/assets/css/float-contact-buttons.css'));
    }

    public function gpc_contact_buttons()
    {
        $contact_buttons_left = carbon_get_theme_option('gpc_floating_buttons_left');
        $contact_buttons_right = carbon_get_theme_option('gpc_floating_buttons_right');
        $buttons_show_left = carbon_get_theme_option('gpc_floating_buttons_left_show');
        $buttons_show_right = carbon_get_theme_option('gpc_floating_buttons_right_show');

        $float_btn_container_class = "gpc-floating-buttons";
        $style = '';
        $total_left = !empty($buttons_show_left) ? count($contact_buttons_left) : 0;
        $total_right = !empty($buttons_show_right) ? count($contact_buttons_right) : 0;
        $total_column = $total_left + $total_right;

        $is_mobile_fixed = carbon_get_theme_option('gpc_floating_buttons_mobile_fixed');
        if (!empty($is_mobile_fixed)) {
            $float_btn_container_class .= " mobile-fixed";
            $style .= " --columns: " . $total_column;
        }

        $is_reverse_order_on_mobile = carbon_get_theme_option('gpc_floating_buttons_reverse_order_on_mobile');
        if (!empty($is_reverse_order_on_mobile)) {
            $float_btn_container_class .= " reverse-order-on-mobile";
        }

        echo '<div class="' . $float_btn_container_class . '" style="'.$style.'">';

        $this->render_buttons($contact_buttons_left, 'left');
        $this->render_buttons($contact_buttons_right, 'right');
        echo '</div>';

        if (!carbon_get_theme_option('gpc_floating_buttons_fix_zalo')) {
            return;
        }

        $contact_buttons = array_merge($contact_buttons_left, $contact_buttons_right);
        $zalo_buttons = array_filter($contact_buttons, function ($button) {
            return $button['type'] === 'zalo';
        });

        if (empty($zalo_buttons)) {
            return;
        }

        $this->render_fix_zalo($zalo_buttons);
    }

    private function render_buttons($buttons, $position = 'left')
    {
        $buttons_show = carbon_get_theme_option('gpc_floating_buttons_'.$position.'_show');
        if(empty($buttons_show) || empty($buttons)) {
            return;
        }

        $shaking_btn_arr = carbon_get_theme_option('gpc_floating_buttons_'.$position.'_has_effect');
        $class = 'gpc-floating-buttons__group is-'.$position;

        $style = " --cols: " . count($buttons);

        foreach($shaking_btn_arr as $item) {
            $class .= ' has-effect-shake-'.$item;
        }

        ?>
        <section class="<?php echo $class; ?>" style="<?php echo $style; ?>">
            <?php
                foreach ($buttons as $button) {
                    $this->render_button($button);
                }
            ?>
        </section>
        <?php
    }

    private function render_button($button)
    {
        $type = $button['type'];
        $title = $button['title'];
        $link = $button['link'];
        $color = $button['color'];
        $icon_image = $button['icon_image'];
        $css_class = $button['css_class'];

        $button_class = 'class="gpc-floating-buttons__item is-type-' . $type . ' ' . $css_class . '" ';

        $button_style = ' style="';
        if (!empty($color)) {
            $button_style .= 'background-color:' . $color . ';';
        }
        if (!empty($icon_image)) {
            $image_url = wp_get_attachment_image_src($icon_image);
            $button_style .= 'background-image: url(' . $image_url[0] . ');';
        }
        $button_style .= '" ';

        echo '<div ' . $button_class . '>';
        if (!empty($link)) {
            echo '<a ' . $button_style . 'href="' . $link . '" title="' . $title . '" rel="nofollow" target="_blank"></a>';
        }

        echo '</div>';
    }

    private function render_fix_zalo($buttons)
    {
        $zalo_accounts = array_reduce($buttons, function ($result, $item) {
            $result[$item['phone']] = $item['qrcode'];
            return $result;
        }, []);
        ?>

        <script>
            var zalo_acc = <?php echo json_encode($zalo_accounts); ?>;

            function devvnCheckLinkAvailability(link, successCallback, errorCallback) {
                var hiddenIframe = document.querySelector("#hiddenIframe");

                if (!hiddenIframe) {
                    hiddenIframe = document.createElement("iframe");
                    hiddenIframe.id = "hiddenIframe";
                    hiddenIframe.style.display = "none";
                    document.body.appendChild(hiddenIframe);
                }

                var timeout = setTimeout(function() {
                    errorCallback("Link is not supported.");
                    window.removeEventListener("blur", handleBlur);
                }, 2500);

                var result = {};

                function handleMouseMove(event) {
                    if (!result.x) {
                        result = {
                            x: event.clientX,
                            y: event.clientY,
                        };
                    }
                }

                function handleBlur() {
                    clearTimeout(timeout);
                    window.addEventListener("mousemove", handleMouseMove);
                }

                window.addEventListener("blur", handleBlur);

                window.addEventListener(
                    "focus",
                    function onFocus() {
                        setTimeout(function() {
                            if (document.hasFocus()) {
                                successCallback(function(pos) {
                                    if (!pos.x) {
                                        return true;
                                    }
                                    var screenWidth =
                                        window.innerWidth ||
                                        document.documentElement.clientWidth ||
                                        document.body.clientWidth;
                                    var alertWidth = 300;
                                    var alertHeight = 100;
                                    var isXInRange =
                                        pos.x - 100 < 0.5 * (screenWidth + alertWidth) &&
                                        pos.x + 100 > 0.5 * (screenWidth + alertWidth);
                                    var isYInRange =
                                        pos.y - 40 < alertHeight && pos.y + 40 > alertHeight;
                                    return isXInRange && isYInRange ?
                                        "Link can be opened." :
                                        "Link is not supported.";
                                }(result));
                            } else {
                                successCallback("Link can be opened.");
                            }

                            window.removeEventListener("focus", onFocus);
                            window.removeEventListener("blur", handleBlur);
                            window.removeEventListener("mousemove", handleMouseMove);
                        }, 500);
                    }, {
                        once: true
                    }
                );

                hiddenIframe.contentWindow.location.href = link;
            }

            Object.keys(zalo_acc).map(function(sdt, index) {
                let qrcode = zalo_acc[sdt];
                const zaloLinks = document.querySelectorAll('a[href*="zalo.me/' + sdt + '"]');
                zaloLinks.forEach((zalo) => {
                    zalo.addEventListener("click", (event) => {
                        event.preventDefault();
                        const userAgent = navigator.userAgent.toLowerCase();
                        const isIOS = /iphone|ipad|ipod/.test(userAgent);
                        const isAndroid = /android/.test(userAgent);
                        let redirectURL = null;

                        if (isIOS) {
                            redirectURL = 'zalo://qr/p/' + qrcode;
                            window.location.href = redirectURL;
                        } else if (isAndroid) {
                            redirectURL = 'zalo://zaloapp.com/qr/p/' + qrcode;
                            window.location.href = redirectURL;
                        } else {
                            redirectURL = 'zalo://conversation?phone=' + sdt;
                            zalo.classList.add("zalo_loading");

                            devvnCheckLinkAvailability(
                                redirectURL,
                                function(result) {
                                    zalo.classList.remove("zalo_loading");
                                },
                                function(error) {
                                    zalo.classList.remove("zalo_loading");
                                    redirectURL = 'https://chat.zalo.me/?phone=' + sdt;
                                    window.location.href = redirectURL;
                                }
                            );
                        }
                    });
                });
            });

            //Thêm css vào site để lúc ấn trên pc trong lúc chờ check chuyển hướng sẽ không ấn vào thẻ a đó được nữa
            var styleElement = document.createElement("style");
            var cssCode = ".zalo_loading { pointer-events: none; }";
            styleElement.innerHTML = cssCode;
            document.head.appendChild(styleElement);
        </script>
    <?php
    }

    private function render_icon($button)
    {
        $icon_type = $button['icon_type'];

        $icon_html = '';
        switch ($icon_type) {
            case 'icon':
                $icon_html = $this->render_icon_type_icon($button);
                break;
            case 'image':
                $icon_html = $this->render_icon_type_image($button);
                break;
            default:
                $icon_html = $this->render_icon_type_custom($button);
                break;
        }

        return $icon_html;
    }

    private function render_icon_type_icon($button)
    {
        $icon = $button['icon'];
        if (empty($icon)) {
            return '';
        }

        $html = '';

        if ($icon['provider'] === 'custom') {
            $html = '<span class="floating-contact-icon">';
            $html .= '<img alt="' . $button['title'] . '" src="' . $icon['icon'] . '" />';
            $html .= '</span>';
        } else {
            $html = '<span class="floating-contact-icon"><i class="' . $icon['class'] . '"></i></span>';
        }

        return $html;
    }

    private function render_icon_type_image($button)
    {
        $image_id = $button['icon_image'];
        if (empty($image_id)) {
            return '';
        }

        $icon_html = '';

        $image_url = wp_get_attachment_image_src($image_id);
        $icon_html = '<span class="floating-contact-icon">';
        $icon_html .= '<img alt="' . $button['title'] . '" src="' . $image_url[0] . '" />';
        $icon_html .= '</span>';

        return $icon_html;
    }

    private function render_icon_type_custom($button)
    {
        if (empty($button['icon_custom'])) {
            return '';
        }
        return '<span class="floating-contact-icon"><i class="' . $button['icon_custom'] . '"></i></span>';
    }
}
