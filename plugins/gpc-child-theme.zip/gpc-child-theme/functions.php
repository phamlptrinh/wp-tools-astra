<?php
/**
 * gpc-child-theme Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package gpc-child-theme
 * @since 1.0.0
 */

use GpcChildTheme\Site\SiteInit;

/**
 * Define Constants
 */
define( 'GPC_CHILD_THEME_VERSION', '1.0.0' );
define( 'GPC_CHILD_THEME_DIR_URL', get_stylesheet_directory_uri() );
define( 'GPC_CHILD_THEME_DIR', get_stylesheet_directory() );

require_once __DIR__ . '/vendor/autoload.php';
SiteInit::instance();