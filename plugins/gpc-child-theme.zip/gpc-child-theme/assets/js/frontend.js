(function($) {

	class KadenceFormDatePicker {
		constructor() {
			this.init();
		}

		init() {
			$('.datepicker input').each(function() {
				new GDatetimepicker(this);
			});

			$('.datetimepicker input').each(function() {
				new GDatetimepicker(this, {
					timepicker: true,
				});
			});
		}
	}

	$( document ).ready(function() {
		new KadenceFormDatePicker();
	});

})(jQuery)

