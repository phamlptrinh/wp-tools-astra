(function ( $ ) {

	'use strict';

})( jQuery );
