(function ( $ ) {

	'use strict';

})( jQuery );
